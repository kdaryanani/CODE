#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>

#define SERVER_PORT 5123
#define maxBuf 256


    
int main(int argc, char *argv[]) {
	struct sockaddr_in si_server;
    char *buf[]={"","","","","",NULL};
    int i; 
    
    typedef struct packet{
        unsigned int sequence;
        char buffer[maxBuf];
        unsigned int checksum;
    }PACK;
    
    PACK packet;
    packet.sequence = 0;
    packet.checksum = 15;

	// Write zeroes in all fields of sockaddr_in struct
	bzero((char *) &si_server, sizeof(si_server));
	// specify that we are using an IPv4 address 
	si_server.sin_family = AF_INET;
	// Allow use of any interface
	si_server.sin_addr.s_addr = INADDR_ANY;
	// assign port number and convert host format to network format
	si_server.sin_port = htons(SERVER_PORT);
    
    
    
    
    int s1=socket(AF_INET, SOCK_DGRAM, 0);// come back to that
    
    bind(s1, (struct sockaddr *) &si_server, sizeof(si_server));
    
    
    socklen_t size = sizeof(si_server);
    
    while(1){
        recvfrom(s1, &packet, sizeof(packet), 0, (struct sockaddr *) &si_server, &size); //data
        if (packet.checksum!=15){
            printf("Your checksum did not match");
            break;
        }
        else{
            packet.sequence++;
	    for(i=0; i<strlen(packet.buffer);i++){
		if(packet.buffer[i]>=97 && packet.buffer[i]<=122) 
			packet.buffer[i]=packet.buffer[i]-32;
	    }

        }
        //buf=covertToUpper(packet.buffer);
        
        //printf("Here is your message in uppercase: %s \n", buf);
        
        if(strncmp(packet.buffer,"quit",4)==0) break;
        
        //printf("User1: %s\n ", buf);
        
        //fgets(buf,sizeof(buf),stdin); NO longer hosting a chat
        
        if(strncmp(packet.buffer,"quit",4)==0) break;
        
        if(packet.checksum!=15){
            printf("Your data has been corrupted and the checksum does not match");
            break;
        }
	int x = strlen(packet.buffer);
       	printf("Checksum: %d, Length of message: %d, Message: %s", packet.checksum, x, packet.buffer);  
        sendto(s1, &packet, sizeof(packet), 0, (struct sockaddr *) &si_server, sizeof(si_server)); //data
        
    }
  
    
    shutdown(s1,2);
    return 0;
}

