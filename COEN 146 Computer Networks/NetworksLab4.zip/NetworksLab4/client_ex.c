#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>

#define SERVER_PORT 5123
#define maxBuf 256

int main(int argc, char *argv[]) {
    struct hostent *server;
    struct sockaddr_in si_server;
   
    server = gethostbyname(argv[1]);
    if(server == NULL) {
		// Print error -- Host not found!
		exit(0);
    }
    
    typedef struct packet{
        unsigned int sequence;
        char buffer[maxBuf];
        unsigned int checksum;
    }PACK;
    
    PACK packet;
    packet.sequence=0;
    packet.checksum = 15; 
    //char buf[5][256];
    char *buf[]={"packet one","packet two","packet three","packet four", "packet five", NULL};  
   // buf[0]="lowercase packet one";
    //buf[1]="lowercase packet two";
   // buf[2]="lowercase packet three";
   // buf[3]="lowercase packet four";
   // buf[4]="lowercase packet five";
    
    
	// Write zeroes in sockaddr struct fields	
    bzero((char *) &si_server, sizeof(si_server));
	// Specify that we are using an IPv4 address
    si_server.sin_family = AF_INET;
	// copy the address of the server to the sockaddr struct address field
    bcopy((char *)server->h_addr, (char *)&si_server.sin_addr, server->h_length);
	// assign the port number and convert to network format
    si_server.sin_port = htons(SERVER_PORT);

    int s2= socket(AF_INET, SOCK_DGRAM, 0);// come back to that
    socklen_t size =sizeof(si_server);

    
    //fgets(buf,sizeof(buf),stdin)
    
    while(1){
        
        
        strcpy(packet.buffer,buf[packet.sequence]);
        
        sendto(s2, &packet, sizeof(packet), 0, (struct sockaddr *) &si_server, sizeof(si_server)); //data
        
        
        if(strncmp(packet.buffer,"quit",4)==0) break;
        
        recvfrom(s2, &packet, sizeof(packet), 0, (struct sockaddr *) &si_server, &size);
        if(packet.checksum!=15){
            printf("Your data has been corrupted and the checksum does not match");
            packet.sequence--;
        }
            //data
        
        if(strncmp(packet.buffer,"quit",4)==0) break;
        
        printf("Uppercase is: %s\n ", packet.buffer);
	printf("Checksum = %d , is correct. Length of string %d, Message : %s" , packet.checksum, strlen(packet.buffer), packet.buffer);
	if(packet.sequence >4){
            printf("You have sent 5 packets");
            break;
        }
    }

    shutdown(s2,2); //shutdown socket for client side         
             
    return 0;
    

}


