#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#define SERVER_PORT 5555 //This is not a very good port if everyone is using it.

int main(int argc, char *argv[]) {
	struct sockaddr_in si_server;
    char buf[256]; //initializing the buffer to read in characters to
    


	// Write zeroes in all fields of sockaddr_in struct	
	bzero((char *) &si_server, sizeof(si_server));
	// specify that we are using an IPv4 address 
	si_server.sin_family = AF_INET;
	// Allow use of any interface
	si_server.sin_addr.s_addr = INADDR_ANY;
	// assign port number and convert host format to network format
	si_server.sin_port = htons(SERVER_PORT);

    
    int s1=socket(AF_INET, SOCK_DGRAM, 0);// Creating the socket
    
    bind(s1, (struct sockaddr *) &si_server, sizeof(si_server)); //Basically assigning a namespace to the newly created socked so we can access it
    
    
    recvfrom(s1, argv[2], strlen(argv[2]), 0, (struct sockaddr*) &si_server, sizeof(si_server)); //Retrieve file name
                   
    recvfrom(s1, buf, sizeof(buf), 0, (struct sockaddr *) &si_server, sizeof(si_server)); //Recieve data from the file
                    
    FILE *f = fopen("Transfer.txt", "w"); //The next few lines open the file we want to save to
    if (f == NULL)
    {
        printf("Error opening file!\n");
        exit(1);
    }
    printf("Part 1\n");       
    
    fprintf(f, buf); //write the buffer from test.txt into transfer.txt
                     
    fclose(f); // close file
	
    return 0;
}
