#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#define SERVER_PORT 5555

int main(int argc, char *argv[]) {
    struct hostent *server;
    struct sockaddr_in si_server;
   
    
	// get host name from command line and store in hostent struct
    server = gethostbyname(argv[1]);
    if(server == NULL) {
		// Print error -- Host not found!
		exit(0);
    }

    //if (*argc != 2 ) return; Unnecessary chck
    
    char buf[256]; //Initialize buffer to read in characters
    char arguments[1][256]; //2d array
    int line_nr=0,i;
    
    
    

	// Write zeroes in sockaddr struct fields	
    bzero((char *) &si_server, sizeof(si_server));
	// Specify that we are using an IPv4 address
    si_server.sin_family = AF_INET;
	// copy the address of the server to the sockaddr struct address field
    bcopy((char *)server->h_addr, (char *)&si_server.sin_addr, server->h_length);
	// assign the port number and convert to network format
    si_server.sin_port = htons(SERVER_PORT);
    
    
    
    int s2= socket(AF_INET, SOCK_DGRAM, 0);// Creates the socket to access server
    
    FILE *fp;
    
    fp=fopen(argv[2],"r"); //opens the file provided by the second argument in the command line
    
    if (fp == NULL)
    {
        printf("Could not open command file: %s",argv[1]);
        return;
    }
    
    while (fgets(buf,sizeof(buf),fp)) //fgets retrieves the data line by line
    {
        line_nr++;
        strcpy(arguments[line_nr],buf);// copy lines into the buffer
        
    }
    
    
    (void) fclose(fp); //close file
    
    for (i=1;i<=line_nr;i++) printf("%d,%s\n",i,arguments[i]); /* change <= to < */
    
    *argv=&arguments[0][0];
    //file is now read into buf
    
    sendto(s2, argv[2], sizeof(argv[2]), 0, (struct sockaddr *) &si_server, sizeof(si_server)); //Sends the file name
                   
    sendto(s2, buf, sizeof(buf), 0, (struct sockaddr *) &si_server, sizeof(si_server)); //Sends the actual data
    
    shutdown(s2,2); //shutdown socket for client side         
             
    return 0;
    
}
