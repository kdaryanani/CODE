#include <stdio.h>
#include <stdlib.h>
#include <time.h>

unsigned char *randBytes(int numberOfBytes);


int main (void){
    int i;
    int numberOfBytes = 7000000; // 5 Megabytes,10,15
    char stream[numberOfBytes]; //Creating the character stream
    
    srand((unsigned int) time(NULL)); //Implementing a random function by using the "time"
    for(i=0; i<numberOfBytes-1; i++){
        stream[i] = rand(); //write out the bytes to the stream based on the random value
        printf("%c", stream[i]);
    }
    return 0;
    
}