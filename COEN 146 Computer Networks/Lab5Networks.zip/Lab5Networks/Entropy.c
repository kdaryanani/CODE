#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

#define ALPHASIZE 256 //Defining the Alphabet size like in the Cisco code.

int main(int argc, char*argv[]){
    int i,j,k,x;
    int frequency[ALPHASIZE];
    unsigned char buffer[99];
    int counter = 0;
    
    for(i=0; i<ALPHASIZE; i++){
        frequency[i]=0;
    }
    while((j=read(0,&buffer,sizeof(buffer)))){
        for(k=0; k<j; k++){
            frequency[buffer[k]]++; //Traverse through the frequence array and incremebt value based on the buffer
            counter++;
        }
    }
    
    double probability =0;
    double entropy =0;
    
    for(x=0; x<ALPHASIZE; x++){
        if(frequency[x]){
            probability=(double)frequency[x]/(double)counter; //Algorithm from Cisco to calculate entropy
            entropy += probability*log2(1/probability);
        }
    }
    printf("Entropy is %f \n", entropy); //Prints out files
    return 0;
    //explaination how to compile and run program in read me
}