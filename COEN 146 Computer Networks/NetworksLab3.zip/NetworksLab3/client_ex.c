#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>

#define SERVER_PORT 5123

int main(int argc, char *argv[]) {
    struct hostent *server;
    struct sockaddr_in si_server;
   
    server = gethostbyname(argv[1]);
    if(server == NULL) {
		// Print error -- Host not found!
		exit(0);
    }
    
    char buf[256]; //Initialize char string
    
	// Write zeroes in sockaddr struct fields	
    bzero((char *) &si_server, sizeof(si_server));
	// Specify that we are using an IPv4 address
    si_server.sin_family = AF_INET;
	// copy the address of the server to the sockaddr struct address field
    bcopy((char *)server->h_addr, (char *)&si_server.sin_addr, server->h_length);
	// assign the port number and convert to network format
    si_server.sin_port = htons(SERVER_PORT);

    int s2= socket(AF_INET, SOCK_DGRAM, 0);// come back to that
    socklen_t size =sizeof(si_server);

    
    while(fgets(buf,sizeof(buf),stdin)){
        sendto(s2, buf, sizeof(buf), 0, (struct sockaddr *) &si_server, sizeof(si_server)); //send data
        if(strncmp(buf,"quit",4)==0) break; //quit functionality
        recvfrom(s2, buf, sizeof(buf), 0, (struct sockaddr *) &si_server, &size); //data
        if(strncmp(buf,"quit",4)==0) break;
        printf("User2: %s\n ", buf);
    }

    shutdown(s2,2); //shutdown socket for client side         
             
    return 0;
    

}
