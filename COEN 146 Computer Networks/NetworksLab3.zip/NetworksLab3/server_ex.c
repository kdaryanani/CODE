#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>

#define SERVER_PORT 5123

int main(int argc, char *argv[]) {
	struct sockaddr_in si_server;
    char buf[256]; //Initialize buffer
    

	// Write zeroes in all fields of sockaddr_in struct	
	bzero((char *) &si_server, sizeof(si_server));
	// specify that we are using an IPv4 address 
	si_server.sin_family = AF_INET;
	// Allow use of any interface
	si_server.sin_addr.s_addr = INADDR_ANY;
	// assign port number and convert host format to network format
	si_server.sin_port = htons(SERVER_PORT);

    
    int s1=socket(AF_INET, SOCK_DGRAM, 0);//
    
    bind(s1, (struct sockaddr *) &si_server, sizeof(si_server)); //name socket
    
    socklen_t size = sizeof(si_server);
    while(1){
        recvfrom(s1, buf, sizeof(buf), 0, (struct sockaddr *) &si_server, &size); //data receiving
        if(strncmp(buf,"quit",4)==0) break; //implemented quit functionality
        printf("User1: %s\n ", buf); //print message
        fgets(buf,sizeof(buf),stdin); //recieve line
        if(strncmp(buf,"quit",4)==0) break; //quit
        sendto(s1, buf, sizeof(buf), 0, (struct sockaddr *) &si_server, sizeof(si_server)); //send new
        
    }
  
    
    shutdown(s1,2);
    return 0;
}
