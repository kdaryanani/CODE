package karantank;

import java.awt.geom.Rectangle2D;

public class Shape {

	float x1, x2, y1, y2;
	
	Shape(float x1,float y1){
		this.x1=x1;
		this.y1=y1;
	}
	
	Shape(float x1, float y1, float x2, float y2){
		this.x1=x1;
		this.y1=y1;
		this.x2=x2;
		this.y2=y2;
	}
	
	void drawShape(float a, float b){
		setx1(a);
		sety1(b);
		System.out.println("Drawing Square");
	}
	
	void drawShape(float a, float b, float c, float d){
		setx1(a);
		sety1(b);
		setx2(c);
		sety2(d);
		System.out.println("Drawing Rectangle");
	}
	
	void setx1(float x1){
		this.x1=x1;
	}
	void setx2(float x2){
		this.x2=x2;
	}
	void sety1(float y1){
		this.y1=y1;
	}
	void sety2(float y2){
		this.y2=y2;
	}
	
	public static void main(String args[]){
		Rectangle2D.Float X = new Rectangle2D.Float(10,20,0,0);
		X.setRect(0,0, 20,40);
	}
}
