package karantank;
/**
 *  This is not a real square. It should be called Rectangle. Some shenanagains taking place
 * @author kdaryana
 *
 */
public class Check {
	public static void main(String[] args){
	Square sq =new Square(40,50);
	sq.width = 40;
	sq.height = 50;
	
	System.out.println("sq�s area is " + sq.area());
	}
	//This is the class Check Modified from problem 4 
	
}
