package karantank;


public class Tank {
	double length;
	double width;
	double height;
	
	void printLength(){
		System.out.println("This is the Length"+ length);
	}
	
	void printWidth(){
		System.out.println("This is the Width"+ width);	
	}	
	
	void printHeight(){
		System.out.println("This is the Height"+ height);
	}
	
	void setWidth(double width){
		this.width=width;
	}
	
	void setHeight(double height){
		this.height=height;
	}
	
	void setLength(double length){
		this.length=length;
	}
	
	Tank(){
	}
	
	Tank(double width, double height, double length){
		this.width=width;
		this.height=height;
		this.length=length;
	}
	
	double computeVolume(){
		double volume;
		volume=length*width*height;
		System.out.println("This is the Volume"+ volume);
		return volume;
	}
	public static void main(String args[]){
	
	Tank X = new Tank();
	Tank Y = new Tank(1,2,3);
	
	
	X.printLength();
	X.printHeight();
	X.printWidth();
	
	Y.printHeight();
	Y.printLength();
	Y.printWidth();
	
	X.computeVolume();
	Y.computeVolume();
}
}
	




