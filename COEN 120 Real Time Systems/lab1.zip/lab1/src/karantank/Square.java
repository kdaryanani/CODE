package karantank;

public class Square extends Shape{
	public float width;
	public float height;
	
	Square(float width, float height){
		super(width, height);
		this.width=width;
		this.height=height;
	}
	
	float area(){
		return width*height;
	}
	
	
	
	/**
	 	int width;
	int height;
	
	void setWidth(int width){
		this.width=width;
	}
	
	void setHeight(int height){
		this.height=height;
	}
	
	This is part of question 4. So is the file Check
	 */

}
