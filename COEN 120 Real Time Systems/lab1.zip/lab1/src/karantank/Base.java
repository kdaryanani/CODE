package karantank;

public class Base {
		public int x = 10;
		private int y = 10;
		protected int z = 10;
		int a = 10; //Implicit Default Access Modifier
		
		public int getX()
		{
			return x;
		}
		public void setX(int x)
		{
			this.x = x;
		}
		private int getY()
		{
			return y;
		}
		private void setY(int y)
		{
			this.y = y;
		}
		protected int getZ()
		{
			return z;
		}
		protected void setZ(int z)
		{
			this.z = z;
		}
		int getA()
		{
			return a;
		}
		void setA(int a)
		{
			this.a = a;
		}
	
		public static void main(String args[])
		{
			Base rr = new Base();
			rr.x = 10;
			rr.z = 30;
			rr.y = 20;
			rr.a = 40;
			System.out.println("Before�..Value of x is : " + rr.x);
			rr.setX(20);
			System.out.println("After�.Value of x is : " + rr.x);
			System.out.println("Before�..Value of y is : " + rr.y);
			rr.setY(20);
			System.out.println("After�.Value of y is : " + rr.y);
			System.out.println("Before�..Value of z is : " + rr.z);
			rr.setZ(20);
			System.out.println("After�.Value of z is : " + rr.z);
			System.out.println("Before�..Value of a is : " + rr.a);
			rr.setA(20);
			System.out.println("After�.Value of a is : " + rr.a);
			System.out.println("After�.Value of a is : " + rr.getA());
}
}


//Here is the output for Problem 5
//Before�..Value of x is : 10
//After�.Value of x is : 20
//Before�..Value of y is : 20
//After�.Value of y is : 20
///Before�..Value of z is : 30
//After�.Value of z is : 20
//Before�..Value of a is : 40
//After�.Value of a is : 20
//After�.Value of a is : 20

